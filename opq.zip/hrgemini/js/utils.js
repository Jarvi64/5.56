/**
 * HR-Gemini Utilities Module
 * Pure utility functions with no side effects
 */

const Utils = (() => {
    /**
     * Enhanced HTML sanitizer to prevent XSS.
     * @param {*} str - Input to sanitize
     * @returns {string} Sanitized string
     */
    const sanitizeHTML = (str) => {
        if (str === null || str === undefined) return '';
        return String(str)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    };

    /**
     * Extracts initials from a name string.
     * @param {string} name - Full name
     * @returns {string} Initials (1-2 characters)
     */
    const getInitials = (name) => {
        if (!name) return '?';
        const parts = String(name).trim().split(/\s+/).filter(Boolean);
        if (parts.length === 0) return '?';
        if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
        return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
    };

    /**
     * Gradient palette for avatars
     */
    const AVATAR_GRADIENTS = Object.freeze([
        'linear-gradient(135deg, #6366f1, #a855f7)',
        'linear-gradient(135deg, #f43f5e, #fb923c)',
        'linear-gradient(135deg, #059669, #34d399)',
        'linear-gradient(135deg, #0ea5e9, #22d3ee)',
        'linear-gradient(135deg, #8b5cf6, #d946ef)',
        'linear-gradient(135deg, #f59e0b, #fbbf24)'
    ]);

    /**
     * Generates a consistent gradient based on name hash.
     * @param {string} name - Name to hash
     * @returns {string} CSS gradient string
     */
    const getAvatarGradient = (name) => {
        let hash = 0;
        const str = String(name || '');
        for (let i = 0; i < str.length; i++) {
            hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }
        return AVATAR_GRADIENTS[Math.abs(hash) % AVATAR_GRADIENTS.length];
    };

    /**
     * Updates slider fill percentage.
     * @param {HTMLInputElement} el - Range input element
     */
    const updateSliderFill = (el) => {
        if (!el) return;
        const min = parseFloat(el.min) || 0;
        const max = parseFloat(el.max) || 10;
        const val = parseFloat(el.value) || 0;
        const percentage = ((val - min) / (max - min)) * 100;
        el.style.backgroundSize = `${percentage}% 100%`;
    };

    /**
     * Parses tags from a delimited string.
     * @param {string} val - Pipe or comma delimited string
     * @returns {string[]} Array of trimmed tags
     */
    const parseTags = (val) => {
        if (!val) return [];
        const str = String(val);
        const delimiter = str.includes('|') ? '|' : ',';
        return str.split(delimiter).map(t => t.trim()).filter(Boolean);
    };

    /**
     * Renders tags for a delimited string.
     * @param {string} tagStr - Delimited string of tags
     * @param {number|null} [limit=null] - Maximum number of tags to display
     * @returns {string} HTML string
     */
    const renderTags = (tagStr, limit = null) => {
        if (!tagStr) return '';
        const tags = String(tagStr).split(/[|,]/).map(t => t.trim()).filter(Boolean);
        if (tags.length === 0) return '';

        const visibleTags = limit ? tags.slice(0, limit) : tags;
        const remainingCount = limit ? tags.length - limit : 0;

        let html = '<div class="tag-container">';
        visibleTags.forEach(tag => {
            html += `<span class="badge badge-neutral">${sanitizeHTML(tag)}</span> `;
        });

        if (remainingCount > 0) {
            html += `<span class="badge badge-neutral tag-more">+${remainingCount} more</span>`;
        }

        html += '</div>';
        return html;
    };

    /**
     * Copies text to clipboard with legacy fallback.
     */
    const copyToClipboard = async (text) => {
        if (!text) return;

        const handleSuccess = () => Toast.success('Copied to clipboard');
        const handleError = () => Toast.error('Failed to copy');

        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(text);
                handleSuccess();
            } else {
                throw new Error('Clipboard API unavailable');
            }
        } catch (err) {
            // Fallback for non-secure contexts
            const textArea = document.createElement("textarea");
            textArea.value = text;
            textArea.style.position = "fixed";
            textArea.style.left = "-9999px";
            textArea.style.top = "0";
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            try {
                const successful = document.execCommand('copy');
                if (successful) handleSuccess();
                else handleError();
            } catch (err) {
                handleError();
            }
            document.body.removeChild(textArea);
        }
    };

    /**
     * Safely parses a float value.
     * @param {*} val - Value to parse
     * @param {number} [defaultVal=0] - Default if parse fails
     * @returns {number} Parsed float or default
     */
    const safeFloat = (val, defaultVal = 0) => {
        const f = parseFloat(val);
        return isNaN(f) ? defaultVal : f;
    };

    /**
     * Safely parses an integer value.
     * @param {*} val - Value to parse
     * @param {number} [defaultVal=0] - Default if parse fails
     * @returns {number} Parsed integer or default
     */
    const safeInt = (val, defaultVal = 0) => {
        const i = parseInt(val, 10);
        return isNaN(i) ? defaultVal : i;
    };

    /**
     * Debounces a function call.
     * @param {Function} fn - Function to debounce
     * @param {number} delay - Delay in ms
     * @returns {Function} Debounced function
     */
    const debounce = (fn, delay) => {
        let timeoutId;
        return (...args) => {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => fn(...args), delay);
        };
    };

    /**
     * Throttles a function call.
     * @param {Function} fn - Function to throttle
     * @param {number} limit - Minimum time between calls in ms
     * @returns {Function} Throttled function
     */
    const throttle = (fn, limit) => {
        let inThrottle;
        return (...args) => {
            if (!inThrottle) {
                fn(...args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    };

    /**
     * Creates a circular progress SVG.
     * @param {object} options - Configuration options
     * @returns {string} SVG HTML string
     */
    const createCircularProgress = ({ value, size = 32, strokeWidth = 2, label = '' }) => {
        const radius = (size / 2) - (strokeWidth / 2);
        const circumference = 2 * Math.PI * radius;
        const percentage = Math.min(100, Math.max(0, (value / 10) * 100));
        const offset = circumference * (1 - percentage / 100);
        
        const gradientId = `grad-${Math.floor(Math.random() * 1000000)}`;
        let stopColor1, stopColor2;
        
        if (value >= 7.5) {
            stopColor1 = '#10b981'; // emerald-500
            stopColor2 = '#34d399'; // emerald-400
        } else if (value >= 5) {
            stopColor1 = '#f59e0b'; // amber-500
            stopColor2 = '#fbbf24'; // amber-400
        } else {
            stopColor1 = '#ef4444'; // red-500
            stopColor2 = '#f87171'; // red-400
        }

        const fontSize = size <= 32 ? '0.65rem' : (size <= 48 ? '0.85rem' : '1.4rem');

        return `
            <div class="circular-progress" style="position: relative; width: ${size}px; height: ${size}px;" title="${label}: ${value}">
                <svg width="${size}" height="${size}" style="transform: rotate(-90deg); filter: drop-shadow(0 0 2px rgba(0,0,0,0.1));">
                    <defs>
                        <linearGradient id="${gradientId}" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="${stopColor1}" />
                            <stop offset="100%" stop-color="${stopColor2}" />
                        </linearGradient>
                    </defs>
                    <circle cx="${size/2}" cy="${size/2}" r="${radius}" fill="none" stroke="var(--border)" stroke-width="${strokeWidth}" stroke-opacity="0.3"></circle>
                    <circle cx="${size/2}" cy="${size/2}" r="${radius}" fill="none" stroke="url(#${gradientId})" stroke-width="${strokeWidth}" 
                            stroke-dasharray="${circumference}" 
                            stroke-dashoffset="${offset}"
                            stroke-linecap="round"
                            style="transition: stroke-dashoffset 1s cubic-bezier(0.34, 1.56, 0.64, 1);"></circle>
                </svg>
                <div style="position: absolute; top: 52%; left: 50%; transform: translate(-50%, -50%); 
                            font-size: ${fontSize}; font-weight: 800; color: var(--foreground); font-family: 'Outfit', sans-serif;">
                    ${value}
                </div>
            </div>
            ${label ? `<span class="circular-progress-label">${label}</span>` : ''}
        `;
    };

    /**
     * Finds a key in an object by partial match.
     * @param {object} obj - Object to search
     * @param {string[]} keywords - Keywords to match
     * @param {string[]} [excludeKeywords=[]] - Keywords to exclude
     * @returns {string|null} Matching key or null
     */
    const findKeyByPartialMatch = (obj, keywords, excludeKeywords = []) => {
        const keys = Object.keys(obj);
        return keys.find(k => {
            const lower = k.toLowerCase();
            const hasKeyword = keywords.some(kw => lower.includes(kw.toLowerCase()));
            const hasExclude = excludeKeywords.some(ex => lower.includes(ex.toLowerCase()));
            return hasKeyword && !hasExclude;
        }) || null;
    };

    /**
     * Generates a unique ID.
     * @returns {string} UUID
     */
    const generateId = () => {
        if (typeof crypto !== 'undefined' && crypto.randomUUID) {
            return crypto.randomUUID();
        }
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    };

    /**
     * Clamps a number between min and max.
     * @param {number} val - Value to clamp
     * @param {number} min - Minimum value
     * @param {number} max - Maximum value
     * @returns {number} Clamped value
     */
    const clamp = (val, min, max) => Math.min(max, Math.max(min, val));

    /**
     * Checks if a value is truthy (handles string booleans).
     * @param {*} val - Value to check
     * @returns {boolean} Boolean result
     */
    const isTruthy = (val) => {
        if (typeof val === 'boolean') return val;
        if (typeof val === 'number') return val === 1;
        const str = String(val).toLowerCase().trim();
        return str === 'true' || str === 'yes' || str === '1';
    };

    /**
     * Toast notification system
     */
    const Toast = {
        container: null,
        
        init() {
            if (this.container) return;
            this.container = document.createElement('div');
            this.container.id = 'toast-container';
            this.container.className = 'toast-container';
            document.body.appendChild(this.container);
        },
        
        show(message, type = 'info', duration = 3000) {
            this.init();
            
            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            
            const icons = {
                success: 'check-circle',
                error: 'x-circle',
                warning: 'alert-triangle',
                info: 'info'
            };
            
            toast.innerHTML = `
                <i data-lucide="${icons[type] || 'info'}" width="18" height="18"></i>
                <span>${sanitizeHTML(message)}</span>
            `;
            
            this.container.appendChild(toast);
            // Ensure lucide is available globally or imported
            if (typeof lucide !== 'undefined' && lucide.createIcons) {
                lucide.createIcons();
            }
            
            // Trigger animation
            requestAnimationFrame(() => {
                toast.classList.add('toast-show');
            });
            
            // Auto remove
            setTimeout(() => {
                toast.classList.remove('toast-show');
                toast.classList.add('toast-hide');
                setTimeout(() => toast.remove(), 300);
            }, duration);
            
            return toast;
        },
        
        success(message, duration) { return this.show(message, 'success', duration); },
        error(message, duration) { return this.show(message, 'error', duration); },
        warning(message, duration) { return this.show(message, 'warning', duration); },
        info(message, duration) { return this.show(message, 'info', duration); }
    };

    /**
     * Loading overlay utilities
     */
    const Loading = {
        overlay: null,
        
        show(message = 'Loading...') {
            if (this.overlay) return;
            
            this.overlay = document.createElement('div');
            this.overlay.className = 'loading-overlay';
            this.overlay.innerHTML = `
                <div class="loading-spinner">
                    <div class="spinner"></div>
                    <span class="loading-text">${sanitizeHTML(message)}</span>
                </div>
            `;
            document.body.appendChild(this.overlay);
            
            requestAnimationFrame(() => {
                this.overlay.classList.add('show');
            });
        },
        
        hide() {
            if (!this.overlay) return;
            
            this.overlay.classList.remove('show');
            setTimeout(() => {
                this.overlay?.remove();
                this.overlay = null;
            }, 200);
        },
        
        update(message) {
            if (!this.overlay) return;
            const textEl = this.overlay.querySelector('.loading-text');
            if (textEl) textEl.textContent = message;
        }
    };

    return {
        sanitizeHTML,
        getInitials,
        getAvatarGradient,
        updateSliderFill,
        parseTags,
        renderTags,
        copyToClipboard,
        safeFloat,
        safeInt,
        debounce,
        throttle,
        createCircularProgress,
        findKeyByPartialMatch,
        generateId,
        clamp,
        isTruthy,
        Toast,
        Loading,
        AVATAR_GRADIENTS
    };
})();

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Utils;
} else {
    window.Utils = Utils;
}
