/**
 * HR-Gemini Data Processing Module
 * Handles data import, transformation, scoring, and filtering
 */

const DataProcessor = (() => {
    /**
     * Processes uploaded Excel file.
     * @param {Event} event - File input change event
     * @returns {Promise<void>}
     */
    const handleFileUpload = async (event) => {
        const file = event.target.files?.[0];
        if (!file) return;

        AppState.setLoading(true);

        try {
            const data = await readExcelFile(file);
            if (data.length > 0) {
                // Assign unique IDs
                const dataWithIds = data.map(row => ({
                    ...row,
                    _id: Utils.generateId()
                }));

                AppState.setRawData(dataWithIds);
                AppState.clearStatusOverrides();
                setupColumns(dataWithIds[0]);
                
                // Show table UI
                toggleDataView(true);
                UIRenderer.renderHeaders();
                recalculateAndRender();
                Utils.Toast.success(`Successfully uploaded ${data.length} candidates`);
            }
        } catch (error) {
            console.error('File upload error:', error);
            Utils.Toast.error('Error reading file. Please ensure it\'s a valid Excel file.');
        } finally {
            AppState.setLoading(false);
            // Reset input for re-upload of same file
            event.target.value = '';
        }
    };

    /**
     * Reads Excel file and returns JSON data.
     * @param {File} file - Excel file
     * @returns {Promise<object[]>}
     */
    const readExcelFile = (file) => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (e) => {
                try {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: 'array' });
                    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                    const jsonData = XLSX.utils.sheet_to_json(firstSheet, { defval: '' });
                    resolve(jsonData);
                } catch (err) {
                    reject(err);
                }
            };
            
            reader.onerror = () => reject(new Error('File read failed'));
            reader.readAsArrayBuffer(file);
        });
    };

    /**
     * Toggles between empty state and data view.
     * @param {boolean} showData - Whether to show data view
     */
    const toggleDataView = (showData) => {
        const emptyState = document.getElementById('empty-state');
        const tableWrapper = document.getElementById('table-wrapper');
        const toolbar = document.getElementById('table-toolbar');
        const pagination = document.getElementById('pagination-container');

        if (emptyState) emptyState.style.display = showData ? 'none' : 'flex';
        if (tableWrapper) tableWrapper.style.display = showData ? 'flex' : 'none';
        if (toolbar) toolbar.style.display = showData ? 'flex' : 'none';
        if (pagination) pagination.style.display = showData ? 'flex' : 'none';
    };

    /**
     * Sets up column definitions from data sample.
     * @param {object} rowSample - First row of data
     */
    const setupColumns = (rowSample) => {
        const keys = Object.keys(rowSample);

        // Build field mapping
        AppState.setFieldMapping({
            candidate: Utils.findKeyByPartialMatch(rowSample, ['name']) || '',
            experience: Utils.findKeyByPartialMatch(rowSample, ['years of experience'], ['relevant']) || '',
            domainMatch: Utils.findKeyByPartialMatch(rowSample, ['domain match']) || '',
            skills: Utils.findKeyByPartialMatch(rowSample, ['skill']) || '',
            email: Utils.findKeyByPartialMatch(rowSample, ['email']) || '',
            phone: Utils.findKeyByPartialMatch(rowSample, ['phone', 'mobile']) || ''
        });

        // Map columns with data keys
        const mappedCols = AppState.CORE_COLUMNS.map(col => {
            if (['contact', 'subcards', 'score', 'status'].includes(col.type)) {
                return { ...col };
            }
            const foundKey = keys.find(k => {
                const lower = k.toLowerCase();
                return col.keyMatches?.some(m => lower.includes(m) && !lower.includes('score'));
            });
            return { ...col, dataKey: foundKey };
        });

        AppState.setColumns(mappedCols);
        UIRenderer.renderColumnToggles();
        UIRenderer.renderHeaders();
    };

    /**
     * Calculates final score for a single row.
     * @param {object} row - Data row
     * @returns {number} Calculated score (0-100)
     */
    const calculateFinalScore = (row) => {
        const keys = Object.keys(row);
        let weightedSum = 0;
        const totalWeight = AppState.getTotalWeight();

        if (totalWeight === 0) return 0;

        AppState.SCORING_PARAMS.forEach(param => {
            const key = keys.find(k => {
                const lower = k.toLowerCase();
                return lower.includes('score') && param.keywords.some(kw => lower.includes(kw));
            });
            const value = key ? Utils.safeFloat(row[key]) : 0;
            weightedSum += value * AppState.weights[param.id];
        });

        return Math.round((weightedSum / totalWeight) * 10);
    };

    /**
     * Extracts subscores for a row.
     * @param {object} row - Data row
     * @returns {object[]} Array of subscore objects
     */
    const extractSubscores = (row) => {
        const keys = Object.keys(row);
        return AppState.SCORING_PARAMS.map(param => {
            const key = keys.find(k => {
                const lower = k.toLowerCase();
                return lower.includes('score') && param.keywords.some(kw => lower.includes(kw));
            });
            return {
                id: param.id,
                label: param.label,
                abbr: param.abbr,
                value: key ? Utils.safeFloat(row[key]) : 0
            };
        });
    };

    /**
     * Recalculates all scores and statuses, then renders.
     */
    const recalculateAndRender = () => {
        const counts = { Shortlisted: 0, Borderline: 0, Rejected: 0 };

        const processed = AppState.rawData.map(row => {
            const score = calculateFinalScore(row);
            const override = AppState.statusOverrides.get(row._id);
            const status = override || AppState.getStatusFromScore(score);
            
            counts[status]++;

            return {
                ...row,
                _calculatedScore: score,
                _calculatedStatus: status,
                _hasOverride: !!override,
                _subscores: extractSubscores(row)
            };
        });

        AppState.setProcessedData(processed);
        updateSidebarCounts(counts);
        
        // Apply sort if any
        applyCurrentSort();
        updateFilteredData();
        
        // Render based on view mode
        if (AppState.viewMode === 'table') {
            document.getElementById('table-wrapper').style.display = 'flex';
            document.getElementById('kanban-view').style.display = 'none';
            document.getElementById('pagination-container').style.display = 'flex';
            UIRenderer.renderTable();
        } else {
            document.getElementById('table-wrapper').style.display = 'none';
            document.getElementById('kanban-view').style.display = 'flex';
            document.getElementById('pagination-container').style.display = 'none';
            UIRenderer.renderKanban();
        }
    };

    /**
     * Updates sidebar count displays.
     * @param {object} counts - Status counts
     */
    const updateSidebarCounts = (counts) => {
        const shortEl = document.getElementById('count-shortlisted');
        const borderEl = document.getElementById('count-borderline');
        const rejectEl = document.getElementById('count-rejected');

        if (shortEl) shortEl.textContent = counts.Shortlisted;
        if (borderEl) borderEl.textContent = counts.Borderline;
        if (rejectEl) rejectEl.textContent = counts.Rejected;
    };

    /**
     * Applies current sort to processed data.
     */
    const applyCurrentSort = () => {
        const { colId, dir } = AppState.currentSort;
        if (!colId) return;

        const colDef = AppState.columns.find(c => c.id === colId);
        if (!colDef) return;

        const data = [...AppState.processedData];

        if (colId === 'Exp' && colDef.dataKey) {
            data.sort((a, b) => (Utils.safeFloat(a[colDef.dataKey]) - Utils.safeFloat(b[colDef.dataKey])) * dir);
        } else if (colId === 'Score') {
            data.sort((a, b) => (a._calculatedScore - b._calculatedScore) * dir);
        } else if (colDef.sortable && colDef.dataKey) {
            data.sort((a, b) => {
                const vA = String(a[colDef.dataKey] || '').toLowerCase();
                const vB = String(b[colDef.dataKey] || '').toLowerCase();
                return vA.localeCompare(vB) * dir;
            });
        }

        AppState.setProcessedData(data);
    };

    /**
     * Filters data based on current filter state.
     */
    const updateFilteredData = () => {
        const { search, minExp, domainMatch, status } = AppState.filters;
        const { experience, domainMatch: domainKey } = AppState.fieldMapping;

        const filtered = AppState.processedData.filter(item => {
            // Search filter
            if (search) {
                const searchLower = search.toLowerCase();
                const matchesSearch = Object.values(item).some(val => 
                    String(val).toLowerCase().includes(searchLower)
                );
                if (!matchesSearch) return false;
            }

            // Experience filter
            if (minExp !== null && experience) {
                const expVal = Utils.safeFloat(item[experience]);
                if (expVal < minExp) return false;
            }

            // Domain filter
            if (domainMatch !== 'all' && domainKey) {
                const domVal = Utils.isTruthy(item[domainKey]);
                if (domainMatch === 'true' && !domVal) return false;
                if (domainMatch === 'false' && domVal) return false;
            }

            // Status filter
            if (status !== 'all' && item._calculatedStatus !== status) {
                return false;
            }

            return true;
        });

        AppState.setFilteredData(filtered);
        
        const countEl = document.getElementById('result-count');
        if (countEl) countEl.textContent = `Showing ${filtered.length} candidates`;
    };

    /**
     * Clears all filters and resets to defaults.
     */
    const clearFilters = () => {
        // Reset UI elements
        const searchEl = document.getElementById('search-text');
        const expEl = document.getElementById('filter-exp');
        const domainEl = document.getElementById('filter-domain');
        const statusEl = document.getElementById('filter-status');

        if (searchEl) searchEl.value = '';
        if (expEl) expEl.value = '';
        if (domainEl) domainEl.value = 'all';
        if (statusEl) statusEl.value = 'all';

        AppState.resetFilters();
        updateFilteredData();
        Utils.Toast.info('All filters cleared');
        
        if (AppState.viewMode === 'table') {
            UIRenderer.renderTable();
        } else {
            UIRenderer.renderKanban();
        }
    };

    /**
     * Sorts table by column.
     * @param {string} colId - Column ID
     * @param {number} [forceDir] - Force specific direction
     */
    const sortTable = (colId, forceDir = null) => {
        const current = AppState.currentSort;
        let newDir = forceDir;
        
        if (newDir === null) {
            newDir = current.colId === colId ? -current.dir : 1;
        }

        AppState.setSort(colId, newDir);
        AppState.setCurrentPage(1);
        
        applyCurrentSort();
        updateFilteredData();
        UIRenderer.renderHeaders();
        UIRenderer.renderTable();
    };

    /**
     * Exports processed data to Excel.
     */
    const exportToExcel = () => {
        const data = AppState.processedData;
        if (data.length === 0) {
            alert('No data to export!');
            return;
        }

        // Clean data for export (remove internal fields)
        const exportData = data.map(row => {
            const cleaned = { ...row };
            delete cleaned._id;
            delete cleaned._calculatedScore;
            delete cleaned._calculatedStatus;
            delete cleaned._subscores;
            
            // Add calculated fields with readable names
            cleaned['Final Score'] = row._calculatedScore;
            cleaned['Status'] = row._calculatedStatus;
            
            return cleaned;
        });

        const filename = `Screening_Results_${new Date().toISOString().split('T')[0]}.xlsx`;
        
        // Create worksheet and workbook
        const ws = XLSX.utils.json_to_sheet(exportData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Screening Results');
        
        // Generate file content
        const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        
        // Create a temporary link to trigger download with correct filename
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        
        // Cleanup
        setTimeout(() => {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }, 100);

        Utils.Toast.success('Results exported to Excel');
    };

    return {
        handleFileUpload,
        recalculateAndRender,
        updateFilteredData,
        clearFilters,
        sortTable,
        exportToExcel,
        extractSubscores,
        toggleDataView
    };
})();

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DataProcessor;
} else {
    window.DataProcessor = DataProcessor;
}
