/**
 * HR-Gemini UI Rendering Module
 * Handles all DOM rendering and UI updates
 */

const UIRenderer = (() => {
    /**
     * Renders table headers with dropdown menus.
     */
    const renderHeaders = () => {
        const tableHead = document.getElementById('table-head');
        if (!tableHead) return;

        const columns = AppState.columns;
        let html = '<tr>';

        columns.forEach((col, idx) => {
            if (!col.show) return;

            const widthStyle = col.width ? `style="width:${col.width}"` : '';
            const label = Utils.sanitizeHTML(col.label);
            const isSortable = col.id === 'Exp' || col.id === 'Score';
            const isCandidate = col.id === 'Candidate';
            const { colId, dir } = AppState.currentSort;
            const sortIndicator = colId === col.id ? (dir === 1 ? '↑' : '↓') : '';

            html += `
                <th ${widthStyle} data-col-id="${col.id}" data-col-idx="${idx}">
                    <div class="header-container ${!isCandidate ? 'header-clickable' : ''}" data-col-id="${col.id}">
                        <div class="header-btn">
                            <span>${label}</span>
                            ${sortIndicator ? `<span class="sort-indicator">${sortIndicator}</span>` : ''}
                        </div>
                        ${!isCandidate ? `<i data-lucide="chevron-down" width="12" class="header-chevron"></i>` : ''}
                    </div>
                    
                    ${!isCandidate ? `
                    <div class="dropdown-menu header-dropdown-menu" id="dropdown-${col.id}">
                        ${isSortable ? `
                        <div class="dropdown-item sort-action" data-id="${col.id}" data-dir="1">
                            <i data-lucide="arrow-up" width="14"></i> Sort Ascending
                        </div>
                        <div class="dropdown-item sort-action" data-id="${col.id}" data-dir="-1">
                            <i data-lucide="arrow-down" width="14"></i> Sort Descending
                        </div>
                        ` : ''}
                        <div class="dropdown-item hide-col-action" data-idx="${idx}">
                            <i data-lucide="eye-off" width="14"></i> Hide Column
                        </div>
                    </div>
                    ` : ''}
                    <div class="resize-handle"></div>
                </th>
            `;
        });

        html += '</tr>';
        tableHead.innerHTML = html;
        lucide.createIcons();
    };

    /**
     * Renders column toggle checkboxes in the dropdown.
     */
    const renderColumnToggles = () => {
        const dropdown = document.getElementById('col-dropdown');
        if (!dropdown) return;

        dropdown.innerHTML = '';
        
        AppState.columns.forEach((col, idx) => {
            if (['Score', 'Status', 'Candidate'].includes(col.id)) return;

            const label = document.createElement('label');
            label.className = 'column-toggle-item';
            label.innerHTML = `
                <input type="checkbox" ${col.show ? 'checked' : ''} data-idx="${idx}" class="col-visibility-checkbox">
                <span>${Utils.sanitizeHTML(col.label)}</span>
            `;
            dropdown.appendChild(label);
        });
    };

    /**
     * Renders a single table row.
     * @param {object} item - Data item
     * @returns {string} HTML string
     */
    const renderTableRow = (item) => {
        const { fieldMapping, columns } = AppState;
        let html = '';

        columns.forEach(col => {
            if (!col.show) return;
            html += renderTableCell(col, item, fieldMapping);
        });

        return html;
    };

    /**
     * Renders a single table cell.
     * @param {object} col - Column definition
     * @param {object} item - Data item
     * @param {object} fieldMapping - Field mapping
     * @returns {string} HTML string
     */
    const renderTableCell = (col, item, fieldMapping) => {
        switch (col.type) {
            case 'contact':
                return renderContactCell(item, fieldMapping);
            case 'status':
                return renderStatusCell(item);
            case 'score':
                return renderScoreCell(item);
            case 'subcards':
                return renderSubscoresCell(item._subscores);
            case 'tags':
                return `<td>${Utils.renderTags(item[col.dataKey])}</td>`;
            case 'boolean':
                return renderBooleanCell(item[col.dataKey]);
            default:
                return `<td>${Utils.sanitizeHTML(item[col.dataKey]) || '-'}</td>`;
        }
    };

    /**
     * Renders contact cell with avatar.
     */
    const renderContactCell = (item, fieldMapping) => {
        const name = item[fieldMapping.candidate] || 'Unknown';
        const email = item[fieldMapping.email] || '';
        const phone = item[fieldMapping.phone] || '';

        return `
            <td>
                <div class="name-cell-inner">
                    <div class="avatar candidate-avatar" style="background: ${Utils.getAvatarGradient(name)}">
                        ${Utils.getInitials(name)}
                    </div>
                    <div class="contact-info">
                        <b>${Utils.sanitizeHTML(name)}</b>
                        <div class="contact-details">
                            ${email ? `
                                <span class="contact-item">
                                    <i data-lucide="mail" width="12"></i>
                                    ${Utils.sanitizeHTML(email)}
                                    <button class="btn-copy" data-copy="${Utils.sanitizeHTML(email)}" title="Copy email"><i data-lucide="copy"></i></button>
                                </span>` : ''}
                            ${phone ? `
                                <span class="contact-item">
                                    <i data-lucide="phone" width="12"></i>
                                    ${Utils.sanitizeHTML(phone)}
                                    <button class="btn-copy" data-copy="${Utils.sanitizeHTML(phone)}" title="Copy phone"><i data-lucide="copy"></i></button>
                                </span>` : ''}
                        </div>
                    </div>
                </div>
            </td>
        `;
    };

    /**
     * Renders status cell with badge.
     */
    const renderStatusCell = (item) => {
        const status = item._calculatedStatus;
        const badgeClass = status === 'Shortlisted' ? 'badge-success' : 
                          (status === 'Rejected' ? 'badge-danger' : 'badge-warning');
        
        return `
            <td>
                <div class="status-cell-wrap">
                    <span class="badge ${badgeClass}">${status}</span>
                    ${item._hasOverride ? `<i data-lucide="user-cog" class="override-indicator" title="Manually Adjusted"></i>` : ''}
                </div>
            </td>
        `;
    };

    /**
     * Renders boolean cell.
     */
    const renderBooleanCell = (value) => {
        const isTrue = Utils.isTruthy(value);
        const icon = isTrue ? 'check-circle' : 'x-circle';
        const colorClass = isTrue ? 'text-success' : 'text-muted';
        return `<td><i data-lucide="${icon}" width="18" class="${colorClass}"></i></td>`;
    };

    /**
     * Renders score cell - simple score display.
     */
    const renderScoreCell = (item) => {
        const score = item._calculatedScore;
        const scoreClass = AppState.getScoreClass(score);

        return `
            <td>
                <span class="final-score ${scoreClass}">${score}</span>
            </td>
        `;
    };

    /**
     * Renders subscores cell with circular indicators.
     */
    const renderSubscoresCell = (subscores) => {
        if (!subscores || subscores.length === 0) return '<td>-</td>';

        const circles = subscores.map(s => `
            <div class="subscore-item" title="${s.label}: ${s.value}">
                ${Utils.createCircularProgress({ value: s.value, size: 32, strokeWidth: 2 })}
                <span class="subscore-label">${s.abbr}</span>
            </div>
        `).join('');

        return `<td><div class="subscores-container">${circles}</div></td>`;
    };

    /**
     * Renders the main table.
     */
    const renderTable = () => {
        const tableBody = document.getElementById('table-body');
        if (!tableBody) return;

        const { filteredData, rowsPerPage, currentPage } = AppState;
        const totalPages = Math.ceil(filteredData.length / rowsPerPage) || 1;

        // Adjust current page if out of bounds
        if (currentPage > totalPages) AppState.setCurrentPage(totalPages);
        if (currentPage < 1) AppState.setCurrentPage(1);

        renderPaginationControls(totalPages);

        const startIdx = (AppState.currentPage - 1) * rowsPerPage;
        const pageData = filteredData.slice(startIdx, startIdx + rowsPerPage);

        tableBody.innerHTML = '';

        pageData.forEach((item, idx) => {
            const tr = document.createElement('tr');
            tr.dataset.id = item._id;
            tr.style.setProperty('--row-index', idx);
            tr.innerHTML = renderTableRow(item);
            tableBody.appendChild(tr);
        });

        lucide.createIcons();
    };

    /**
     * Renders pagination controls.
     */
    const renderPaginationControls = (totalPages) => {
        const controls = document.getElementById('pagination-controls');
        const infoEl = document.getElementById('page-info-text');
        const sizeDisplay = document.getElementById('current-page-size');

        if (infoEl) infoEl.textContent = `Page ${AppState.currentPage} of ${totalPages}`;
        if (sizeDisplay) sizeDisplay.textContent = AppState.rowsPerPage;

        if (!controls) return;

        const cp = AppState.currentPage;
        controls.innerHTML = `
            <button class="btn btn-outline btn-icon" ${cp === 1 ? 'disabled' : ''} data-page="1">
                <i data-lucide="chevrons-left" width="16"></i>
            </button>
            <button class="btn btn-outline btn-icon" ${cp === 1 ? 'disabled' : ''} data-page="${cp - 1}">
                <i data-lucide="chevron-left" width="16"></i>
            </button>
            <button class="btn btn-outline btn-icon" ${cp === totalPages ? 'disabled' : ''} data-page="${cp + 1}">
                <i data-lucide="chevron-right" width="16"></i>
            </button>
            <button class="btn btn-outline btn-icon" ${cp === totalPages ? 'disabled' : ''} data-page="${totalPages}">
                <i data-lucide="chevrons-right" width="16"></i>
            </button>
        `;
        lucide.createIcons();
    };

    /**
     * Renders Kanban board view.
     */
    const renderKanban = () => {
        const lists = {
            shortlisted: document.getElementById('list-shortlisted'),
            borderline: document.getElementById('list-borderline'),
            rejected: document.getElementById('list-rejected')
        };

        Object.values(lists).forEach(list => { if (list) list.innerHTML = ''; });

        const counts = { Shortlisted: 0, Borderline: 0, Rejected: 0 };
        const { filteredData, fieldMapping } = AppState;

        // Sort by score descending
        const sortedData = [...filteredData].sort((a, b) => b._calculatedScore - a._calculatedScore);

        sortedData.forEach(item => {
            const status = item._calculatedStatus;
            counts[status]++;

            const card = createKanbanCard(item, fieldMapping);
            const listId = `list-${status.toLowerCase()}`;
            const container = document.getElementById(listId);
            if (container) container.appendChild(card);
        });

        // Update counts
        const countEls = {
            'count-k-short': counts.Shortlisted,
            'count-k-border': counts.Borderline,
            'count-k-reject': counts.Rejected
        };

        Object.entries(countEls).forEach(([id, count]) => {
            const el = document.getElementById(id);
            if (el) el.textContent = count;
        });

        // Add empty states to empty columns
        Object.entries(lists).forEach(([key, list]) => {
            if (list && list.children.length === 0) {
                list.innerHTML = `
                    <div class="kanban-empty">
                        <i data-lucide="inbox" width="32" height="32"></i>
                        <p>No candidates in this category</p>
                    </div>
                `;
            }
        });

        lucide.createIcons();
    };

    /**
     * Creates a Kanban card element.
     * @param {object} item - Data item
     * @param {object} fieldMapping - Field mapping
     * @returns {HTMLElement}
     */
    const createKanbanCard = (item, fieldMapping) => {
        const card = document.createElement('div');
        card.className = 'k-card';
        card.dataset.id = item._id;
        card.draggable = true;

        const name = item[fieldMapping.candidate] || 'Unknown';
        const score = item._calculatedScore;
        const scoreClass = AppState.getScoreClass(score);
        const subscores = item._subscores || [];

        const subscoreCircles = subscores.map(s => `
            <div class="subscore-item-sm" title="${s.label}: ${s.value}">
                ${Utils.createCircularProgress({ value: s.value, size: 28, strokeWidth: 2 })}
                <span class="subscore-label-sm">${s.abbr}</span>
            </div>
        `).join('');

        card.innerHTML = `
            <div class="k-card-header">
                <div class="name-cell-inner">
                    <div class="avatar candidate-avatar k-card-avatar" style="background: ${Utils.getAvatarGradient(name)}">
                        ${Utils.getInitials(name)}
                    </div>
                    <b>${Utils.sanitizeHTML(name)}</b>
                </div>
                <span class="final-score ${scoreClass}">${score}</span>
            </div>
            ${item._hasOverride ? `
                <div class="k-card-override">
                    <i data-lucide="user-cog" width="10"></i> Manual Override
                </div>
            ` : ''}
            <div class="k-card-subscores">
                ${subscoreCircles}
            </div>
            <div class="k-card-skills">
                ${Utils.renderTags(item[fieldMapping.skills], 4).replace('tag-container', 'tag-container tag-container-sm')}
            </div>
        `;

        return card;
    };

    /**
     * Shows candidate detail modal.
     * @param {string} id - Candidate ID
     */
    const showCandidateModal = (id) => {
        const item = AppState.processedData.find(d => d._id === id);
        if (!item) return;

        const modal = document.getElementById('candidate-modal');
        if (!modal) return;

        const { fieldMapping } = AppState;
        const name = item[fieldMapping.candidate] || 'Unknown';
        const email = item[fieldMapping.email] || '';
        const phone = item[fieldMapping.phone] || '';

        // Populate hero section
        const nameEl = document.getElementById('modal-name');
        const avatarEl = document.getElementById('modal-avatar');
        const contactEl = document.getElementById('modal-contact');

        if (nameEl) nameEl.textContent = name;
        if (avatarEl) {
            avatarEl.textContent = Utils.getInitials(name);
            avatarEl.style.background = Utils.getAvatarGradient(name);
        }
        if (contactEl) {
            contactEl.innerHTML = `
                ${email ? `
                    <div class="contact-item">
                        <i data-lucide="mail" width="14"></i> 
                        ${Utils.sanitizeHTML(email)}
                        <button class="btn-copy" data-copy="${Utils.sanitizeHTML(email)}" title="Copy email"><i data-lucide="copy"></i></button>
                    </div>` : ''}
                ${phone ? `
                    <div class="contact-item">
                        <i data-lucide="phone" width="14"></i> 
                        ${Utils.sanitizeHTML(phone)}
                        <button class="btn-copy" data-copy="${Utils.sanitizeHTML(phone)}" title="Copy phone"><i data-lucide="copy"></i></button>
                    </div>` : ''}
            `;
        }

        // Populate total score in header
        const totalScoreEl = document.getElementById('modal-total-score');
        if (totalScoreEl) {
            const score = item._calculatedScore;
            totalScoreEl.textContent = score;
            totalScoreEl.className = `final-score modal-header-score ${AppState.getScoreClass(score)}`;
        }

        // Populate scores
        const scoresEl = document.getElementById('modal-scores');
        if (scoresEl) {
            const subscores = item._subscores || [];
            scoresEl.innerHTML = subscores.map(s => `
                <div class="modal-score-item">
                    ${Utils.createCircularProgress({ value: s.value, size: 52, strokeWidth: 3, label: s.label })}
                </div>
            `).join('');
        }

        // Define fields to exclude (shown in header or internal)
        const excludeFields = new Set([
            fieldMapping.candidate, fieldMapping.email, fieldMapping.phone,
            '_id', '_calculatedScore', '_calculatedStatus', '_subscores', '_hasOverride'
        ]);

        // Define field sections for organized display
        const sections = [
            {
                title: 'Career Overview',
                icon: 'briefcase',
                fields: [
                    { key: 'Current Company', label: 'Current Company' },
                    { key: 'Current Designation', label: 'Current Role' },
                    { key: 'Years of Experience', label: 'Total Experience' },
                    { key: 'Relevant Experience', label: 'Relevant Experience' },
                    { key: 'Previous Companies', label: 'Previous Companies' },
                    { key: 'Previous Roles', label: 'Previous Roles' },
                    { key: 'Highest Education', label: 'Education' },
                    { key: 'Certifications', label: 'Certifications' },
                    { key: 'Languages', label: 'Languages' }
                ]
            },
            {
                title: 'Skills Analysis',
                icon: 'code',
                fields: [
                    { key: 'Skills', label: 'All Skills', type: 'tags' },
                    { key: 'Critical Skills Match', label: 'Critical Skills Match', type: 'tags-success' },
                    { key: 'Nice-to-Have Skills', label: 'Nice-to-Have Skills', type: 'tags' },
                    { key: 'Missing Critical Skills', label: 'Missing Skills', type: 'tags-danger' }
                ]
            },
            {
                title: 'AI Evaluation',
                icon: 'brain',
                fields: [
                    { key: 'Domain Match', label: 'Domain Match', type: 'boolean' },
                    { key: 'Red Flags', label: 'Red Flags', type: 'alert-danger' },
                    { key: 'Notes', label: 'Notes', type: 'text' },
                    { key: 'Summary', label: 'Summary', type: 'text' }
                ]
            },
            {
                title: 'Quick Decision Support',
                icon: 'zap',
                fields: [
                    { key: 'Pros', label: 'Why Hire?', type: 'alert-success' },
                    { key: 'Cons', label: 'Valid Risks', type: 'alert-warning' }
                ]
            }
        ];

        // Populate details grid with sections
        const gridEl = document.getElementById('modal-details-grid');
        if (gridEl) {
            gridEl.innerHTML = '';

            sections.forEach(section => {
                // Check if section has any data
                const hasData = section.fields.some(f => {
                    const val = findFieldValue(item, f.key);
                    return val !== null && val !== undefined && val !== '';
                });

                if (!hasData) return;

                // Create section
                const sectionEl = document.createElement('div');
                sectionEl.className = 'modal-detail-section';
                sectionEl.innerHTML = `
                    <h4 class="modal-detail-section-title">
                        <i data-lucide="${section.icon}" width="16"></i>
                        ${section.title}
                    </h4>
                    <div class="modal-detail-section-content"></div>
                `;

                const contentEl = sectionEl.querySelector('.modal-detail-section-content');

                section.fields.forEach(field => {
                    const value = findFieldValue(item, field.key);
                    if (value === null || value === undefined || value === '') return;

                    const itemEl = document.createElement('div');
                    itemEl.className = 'detail-item';

                    let displayValue = '';
                    switch (field.type) {
                        case 'tags':
                            displayValue = Utils.renderTags(value);
                            break;
                        case 'tags-success':
                            displayValue = renderColoredTags(value, 'success');
                            break;
                        case 'tags-danger':
                            displayValue = renderColoredTags(value, 'danger');
                            break;
                        case 'boolean':
                            const isTrue = Utils.isTruthy(value);
                            displayValue = `<span class="badge ${isTrue ? 'badge-success' : 'badge-danger'}">${isTrue ? 'Yes' : 'No'}</span>`;
                            break;
                        case 'alert-danger':
                            displayValue = `<div class="modal-alert modal-alert-danger"><i data-lucide="alert-triangle" width="14"></i> ${Utils.sanitizeHTML(value)}</div>`;
                            break;
                        case 'alert-success':
                            displayValue = `<div class="modal-alert modal-alert-success"><i data-lucide="check-circle" width="14"></i> ${Utils.sanitizeHTML(value)}</div>`;
                            break;
                        case 'alert-warning':
                            displayValue = `<div class="modal-alert modal-alert-warning"><i data-lucide="info" width="14"></i> ${Utils.sanitizeHTML(value)}</div>`;
                            break;
                        case 'archetype':
                            displayValue = `<span class="badge badge-neutral" style="background:#e0e7ff; color:#3730a3; padding:0.4rem 0.8rem; border:none; font-weight:700;">${Utils.sanitizeHTML(value)}</span>`;
                            break;
                        case 'text-highlight':
                            displayValue = `<div class="modal-text" style="background:var(--secondary); padding:1rem; border-left:4px solid var(--primary); border-radius:4px; font-style:italic;">${Utils.sanitizeHTML(value)}</div>`;
                            break;
                        case 'text':
                            displayValue = `<p class="modal-text">${Utils.sanitizeHTML(value)}</p>`;
                            break;
                        default:
                            displayValue = Utils.sanitizeHTML(value);
                    }

                    itemEl.innerHTML = `
                        <label>${field.label}</label>
                        <div>${displayValue}</div>
                    `;
                    contentEl.appendChild(itemEl);
                });

                gridEl.appendChild(sectionEl);
            });
        }

        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        lucide.createIcons();
    };

    /**
     * Finds field value by partial key match (case-insensitive).
     * @param {object} item - Data item
     * @param {string} searchKey - Key to search for
     * @returns {*} Field value or null
     */
    const findFieldValue = (item, searchKey) => {
        const searchLower = searchKey.toLowerCase();
        const key = Object.keys(item).find(k => k.toLowerCase() === searchLower);
        return key ? item[key] : null;
    };

    /**
     * Renders colored tags.
     * @param {string} value - Comma-separated values
     * @param {string} color - Color type (success, danger, warning)
     * @returns {string} HTML string
     */
    const renderColoredTags = (value, color) => {
        if (!value) return '-';
        const tags = String(value).split(',').map(s => s.trim()).filter(Boolean);
        if (tags.length === 0) return '-';
        return `<div class="tag-container">${tags.map(t => 
            `<span class="badge badge-${color}">${Utils.sanitizeHTML(t)}</span>`
        ).join('')}</div>`;
    };

    /**
     * Closes the candidate modal.
     */
    const closeCandidateModal = () => {
        const modal = document.getElementById('candidate-modal');
        if (modal) modal.classList.remove('show');
        document.body.style.overflow = '';
    };

    return {
        renderHeaders,
        renderColumnToggles,
        renderTable,
        renderPaginationControls,
        renderKanban,
        showCandidateModal,
        closeCandidateModal,
        renderSubscoresCell
    };
})();

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = UIRenderer;
} else {
    window.UIRenderer = UIRenderer;
}
